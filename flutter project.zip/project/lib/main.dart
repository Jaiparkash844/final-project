import 'package:flutter/material.dart';
import 'package:intl/intl.dart';

void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      home: FlashcardApp(),
    );
  }
}

class Flashcard {
  String question;
  String answer;
  String timestamp;

  Flashcard({
    required this.question,
    required this.answer,
    required this.timestamp,
  });
}

class FlashcardApp extends StatefulWidget {
  @override
  _FlashcardAppState createState() => _FlashcardAppState();
}

class _FlashcardAppState extends State<FlashcardApp> {
  List<Flashcard> _flashcards = [];
  final TextEditingController _questionController = TextEditingController();
  final TextEditingController _answerController = TextEditingController();

  void _showDialog(String title, String message) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: Text(title),
        content: Text(message),
        actions: [
          TextButton(
            onPressed: () {
              Navigator.of(context).pop();
            },
            child: Text('OK'),
          ),
        ],
      ),
    );
  }

  void _addFlashcard() {
    if (_questionController.text.isEmpty || _answerController.text.isEmpty) {
      _showDialog('Error', 'Please fill in both question and answer fields.');
    } else {
      String currentTime =
          DateFormat('yyyy-MM-dd HH:mm:ss').format(DateTime.now());
      String numberedQuestion =
          'Question ${_flashcards.length + 1}: ${_questionController.text}';
      setState(() {
        _flashcards.add(
          Flashcard(
            question: numberedQuestion,
            answer: _answerController.text,
            timestamp: currentTime,
          ),
        );
        _questionController.clear();
        _answerController.clear();
      });
      _showDialog('Success', 'Flashcard added at $currentTime.');
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        iconTheme: IconThemeData(color: Colors.white),
        backgroundColor: Colors.blue,
        title:
            Text("Flashcard Quiz App", style: TextStyle(color: Colors.white)),
        centerTitle: true,
      ),
      drawer: Drawer(
        child: ListView(
          padding: EdgeInsets.zero,
          children: [
            DrawerHeader(
              decoration: BoxDecoration(color: Colors.blue),
              child: Text(
                'Flashcard App Menu',
                style: TextStyle(color: Colors.white, fontSize: 24),
              ),
            ),
            ListTile(
              leading: Icon(Icons.home),
              title: Text('Home'),
              iconColor: Colors.blue,
              onTap: () {
                Navigator.pop(context);
              },
            ),
            ListTile(
              leading: Icon(Icons.list),
              iconColor: Colors.blue,
              title: Text('View Flashcards'),
              onTap: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (context) =>
                        FlashcardListScreen(flashcards: _flashcards),
                  ),
                );
              },
            ),
          ],
        ),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: <Widget>[
            Center(
              child: Text('Add New Flashcard',
                  style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
            ),
            Padding(padding: EdgeInsets.all(10)),
            TextField(
              controller: _questionController,
              decoration: InputDecoration(
                labelText: 'Question',
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.all(Radius.circular(10)),
                ),
              ),
            ),
            SizedBox(height: 10),
            TextField(
              controller: _answerController,
              decoration: InputDecoration(
                labelText: 'Answer',
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.all(Radius.circular(10)),
                ),
              ),
            ),
            SizedBox(height: 10),
            ElevatedButton(
              style: ElevatedButton.styleFrom(
                backgroundColor: Colors.blue, // Background color
              ),
              onPressed: _addFlashcard,
              child: Text(
                'Add Flashcard',
                style: TextStyle(color: Colors.white),
              ),
            ),
            SizedBox(height: 20),
            Text(
              'Flashcards Added: ${_flashcards.length}',
              textAlign: TextAlign.center,
              style: TextStyle(fontSize: 16),
            ),
          ],
        ),
      ),
    );
  }
}

class FlashcardListScreen extends StatefulWidget {
  final List<Flashcard> flashcards;

  FlashcardListScreen({required this.flashcards});

  @override
  _FlashcardListScreenState createState() => _FlashcardListScreenState();
}

class _FlashcardListScreenState extends State<FlashcardListScreen> {
  int _currentIndex = 0;

  void _nextFlashcard() {
    setState(() {
      _currentIndex = (_currentIndex + 1) % widget.flashcards.length;
    });
  }

  void _previousFlashcard() {
    setState(() {
      _currentIndex = (_currentIndex - 1 + widget.flashcards.length) %
          widget.flashcards.length;
    });
  }

  void _updateAnswer(int index, String newAnswer) {
    setState(() {
      widget.flashcards[index].answer = newAnswer;
    });
    Navigator.pop(context); // Close the update dialog
  }

  void _deleteFlashcard(int index) {
    setState(() {
      widget.flashcards.removeAt(index);
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("View Flashcards"),
      ),
      body: widget.flashcards.isEmpty
          ? Center(
              child: Text(
                'No flashcards available. Add some from the home screen!',
                textAlign: TextAlign.center,
                style: TextStyle(fontSize: 18),
              ),
            )
          : Padding(
              padding: const EdgeInsets.all(16.0),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [
                  Text(
                    '${widget.flashcards[_currentIndex].question}',
                    style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
                  ),
                  SizedBox(height: 10),
                  Text(
                    'Answer: ${widget.flashcards[_currentIndex].answer}',
                    style: TextStyle(fontSize: 18),
                  ),
                  SizedBox(height: 10),
                  Text(
                    'Added At: ${widget.flashcards[_currentIndex].timestamp}',
                    style: TextStyle(
                        fontSize: 16,
                        fontStyle: FontStyle.italic,
                        color: Colors.blue),
                  ),
                  SizedBox(height: 20),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                    children: [
                      ElevatedButton(
                        onPressed: _previousFlashcard,
                        child: Text('Previous'),
                      ),
                      ElevatedButton(
                        onPressed: _nextFlashcard,
                        child: Text('Next'),
                      ),
                    ],
                  ),
                  SizedBox(height: 20),
                  ElevatedButton(
                    style:
                        ElevatedButton.styleFrom(backgroundColor: Colors.green),
                    onPressed: () {
                      TextEditingController _updateController =
                          TextEditingController();
                      _updateController.text =
                          widget.flashcards[_currentIndex].answer;
                      showDialog(
                        context: context,
                        builder: (BuildContext context) {
                          return AlertDialog(
                            title: Text("Update Answer"),
                            content: TextField(
                              controller: _updateController,
                              decoration:
                                  InputDecoration(labelText: 'New Answer'),
                            ),
                            actions: [
                              TextButton(
                                onPressed: () {
                                  _updateAnswer(
                                      _currentIndex, _updateController.text);
                                },
                                child: Text('Update'),
                              ),
                              TextButton(
                                onPressed: () {
                                  Navigator.pop(context);
                                },
                                child: Text('Cancel'),
                              ),
                            ],
                          );
                        },
                      );
                    },
                    child: Text(
                      'Update Answer',
                      style: TextStyle(color: Colors.white),
                    ),
                  ),
                  SizedBox(height: 10),
                  ElevatedButton(
                    style:
                        ElevatedButton.styleFrom(backgroundColor: Colors.red),
                    onPressed: () {
                      _deleteFlashcard(_currentIndex);
                    },
                    child: Text(
                      'Delete Flashcard',
                      style: TextStyle(color: Colors.white),
                    ),
                  ),
                ],
              ),
            ),
    );
  }
}
